test = {'name': 'a',
 'points': 0.1,
 'suites': [{'cases': [{'code': 'sqlite> SELECT * FROM parta;\n'
                                'DVD f\n'
                                'DVD c\n'
                                'DVD d\n'}],
             'ordered': True,
             'scored': True,
             'setup': 'sqlite> .read q7.sql',
             'type': 'sqlite'},
            {'cases': [{'code': 'sqlite> SELECT * FROM parta;\n'
                                'MANUALMANUALMANUALMANUALMANUALMANUAL\n'}],
             'scored': True,
             'setup': 'sqlite> .read q7.sql',
             'type': 'sqlite'}]}